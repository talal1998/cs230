public abstract class Door extends Cell {

	/**
	 * Instantiates a new door.
	 *
	 * @param xPos the x pos
	 * @param yPos the y pos
	 */
	public Door(int xPos, int yPos) {
		super(xPos, yPos);
	}
}
