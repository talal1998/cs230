javac *.java
java Main
follow on screen instructions, use existing user: Test, to access later levels.